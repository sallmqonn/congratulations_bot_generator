import json
import time
import requests
import base64
from PIL import Image
from io import BytesIO
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FusionBrainAPI:
    def __init__(self, url, api_key, secret_key):
        self.URL = url
        self.AUTH_HEADERS = {
            'X-Key': f'Key {api_key}',
            'X-Secret': f'Secret {secret_key}',
        }

    def get_pipeline(self):
        """Получаем доступные пайплайны"""
        try:
            response = requests.get(self.URL + 'key/api/v1/pipelines', 
                                  headers=self.AUTH_HEADERS,
                                  timeout=30)
            data = response.json()
            return data[0]['id'] if data else None
        except Exception as e:
            logger.error(f"Ошибка при получении pipeline: {e}")
            return None

    def generate_from_text(self, prompt, pipeline_id, images=1, width=1024, height=1024):
        """Генерация изображения из текста"""
        try:
            params = {
                "type": "GENERATE",
                "numImages": images,
                "width": width,
                "height": height,
                "generateParams": {
                    "query": f"{prompt}"
                }
            }

            data = {
                'pipeline_id': (None, pipeline_id),
                'params': (None, json.dumps(params), 'application/json')
            }
            response = requests.post(self.URL + 'key/api/v1/pipeline/run', 
                                   headers=self.AUTH_HEADERS, 
                                   files=data,
                                   timeout=30)
            
            if response.status_code not in [200, 201]:
                logger.error(f"Ошибка API: {response.status_code}, {response.text}")
                return None
                
            data = response.json()
            
            if 'uuid' not in data:
                logger.error(f"Ошибка: в ответе нет uuid. Ответ: {data}")
                return None
                
            return data['uuid']
        except Exception as e:
            logger.error(f"Ошибка при генерации изображения: {e}")
            return None

    def check_generation(self, request_id, attempts=30, delay=10):
        """Проверка статуса генерации с увеличенным количеством попыток"""
        try:
            for i in range(attempts):
                response = requests.get(self.URL + 'key/api/v1/pipeline/status/' + request_id, 
                                      headers=self.AUTH_HEADERS,
                                      timeout=30)
                data = response.json()
                
                logger.info(f"Статус генерации ({i+1}/{attempts}): {data.get('status')}")
                
                if data.get('status') == 'DONE':
                    return data['result']['files']
                elif data.get('status') == 'FAILED':
                    logger.error("Генерация не удалась")
                    return None
                
                time.sleep(delay)
            
            logger.error("Превышено время ожидания генерации")
            return None
        except Exception as e:
            logger.error(f"Ошибка при проверке генерации: {e}")
            return None
    
    def save_image(self, files, file_path):
        """Сохранение изображения"""
        try:
            decoded_data = base64.b64decode(files)
            image = Image.open(BytesIO(decoded_data))
            
            if image.mode == 'RGBA':
                background = Image.new('RGB', image.size, (255, 255, 255))
                background.paste(image, (0, 0), image)
                image = background
            else:
                image = image.convert('RGB')
                
            image.save(file_path, 'JPEG')
            return image
        except Exception as e:
            logger.error(f"Ошибка при сохранении изображения: {e}")
            return None

    def generate_image(self, prompt, output_path="generated_image.jpg"):
        """
        Основная функция для генерации изображения по текстовому промпту
        """
        try:
            pipeline_id = self.get_pipeline()
            if not pipeline_id:
                logger.error("Не удалось получить pipeline ID")
                return False
                
            logger.info(f"Генерация изображения с промптом: {prompt}")
            uuid = self.generate_from_text(prompt, pipeline_id)
            if not uuid:
                logger.error("Не удалось запустить генерацию")
                return False
                
            logger.info(f"Запрос генерации создан, UUID: {uuid}")
            files = self.check_generation(uuid)
            
            if files:
                logger.info("Генерация завершена успешно, сохраняем изображение")
                image = self.save_image(files[0], output_path)
                return image is not None
            else:
                logger.error("Генерация не удалась или превышено время ожидания")
                return False
                
        except Exception as e:
            logger.error(f"Ошибка в generate_image: {e}")
            return False