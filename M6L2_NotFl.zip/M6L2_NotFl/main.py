import telebot
import logic
import os
import time
from PIL import Image, ImageDraw, ImageFont
import json
import requests
import base64
from io import BytesIO
from transformers import pipeline
import translators as ts
import logging

user_states = {}
user_temp_data = {}
bot = telebot.TeleBot("ТокенБота")
api = logic.FusionBrainAPI('https://api-key.fusionbrain.ai/', 'Токен', 'Сикрет')

# Команда для начала работы с ботом
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Я бот для создания открыток. Используй команды:\n"
                         "/text - создать открытку только из текста\n"
                         "Остальные - полная версия бота, точнее pooz1bot")


# Команда для создания открытки только из текста
@bot.message_handler(commands=['text'])
def start_text_process(message):
    user_id = message.from_user.id
    user_states[user_id] = 'waiting_for_text_only'
    bot.send_message(message.chat.id, "Теперь отправьте текст для генерации поздравления, продолжите - с днём[Ваш текст](например, 'закопчёной скумбрии, кремля, капибары')")

# Обработчик получения текста для открытки с изображением
@bot.message_handler(func=lambda message: user_states.get(message.from_user.id) == 'waiting_for_text')
def handle_text_with_image(message):
    user_id = message.from_user.id
    user_text = message.text

    if user_id in user_temp_data and 'image_path' in user_temp_data[user_id]:
        # Используем описание изображения для создания промпта
        description = user_temp_data[user_id].get('description', '')
        prompt = f"Поздравительная открытка с {description}'"
        bot.send_message(message.chat.id, "Начинаю генерацию открытки... Это может занять несколько минут.")
        # Генерируем изображение только на основе текстового промпта
        result_image = api.generate_image_from_text(prompt, user_text)
        
        if result_image:
            # Добавляем кастомный текст на изображение
            
            result_image.save("result.jpg")
            with open("result.jpg", "rb") as photo:
                bot.send_photo(message.chat.id, photo)
            bot.send_message(message.chat.id, "Вот ваша открытка! Надеюсь, она вам понравилась!")
            # Очищаем временные данные
            if os.path.exists(user_temp_data[user_id]['image_path']):
                os.remove(user_temp_data[user_id]['image_path'])
            del user_temp_data[user_id]
            user_states[user_id] = None
        else:
            bot.send_message(message.chat.id, "Извините, произошла ошибка при генерации изображения.")
    else:
        bot.send_message(message.chat.id, "Используйте команду /image")

if __name__ == "__main__":
    print("Бот запущен...")
    
    while True:
        try:
            bot.infinity_polling(
                timeout=60, 
                long_polling_timeout=60,
                logger_level=logging.INFO
            )
        except requests.exceptions.ConnectionError as e:
            print(f"Ошибка соединения: {e}. Переподключаемся через 10 секунд...")
            time.sleep(10)
        except Exception as e:
            print(f"Неожиданная ошибка: {e}. Перезапуск через 5 секунд...")
            time.sleep(5)